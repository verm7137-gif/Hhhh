СБОРКА
1. Установите Android Studio (Koala или новее).
2. File > Open > выберите папку MiniMapHider. Дождитесь Gradle Sync
   (если спросит про Gradle wrapper — согласитесь).
3. Подключите телефон (Отладка по USB) и нажмите Run, либо
   Build > Build APK(s) и установите APK вручную.
