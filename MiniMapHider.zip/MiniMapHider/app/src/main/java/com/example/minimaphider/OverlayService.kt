package com.example.minimaphider

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.max

class OverlayService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_STOP = "stop"
        const val ACTION_REFRESH = "refresh"
        const val ACTION_RESET = "reset"
        const val PREFS = "cfg"
        private const val CHANNEL = "overlay"
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var cover: FrameLayout
    private lateinit var handleView: View
    private lateinit var toggle: TextView
    private lateinit var coverLp: WindowManager.LayoutParams
    private lateinit var toggleLp: WindowManager.LayoutParams
    private var created = false
    private var editMode = true

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val prefs get() = getSharedPreferences(PREFS, MODE_PRIVATE)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_REFRESH -> if (created) applyStyle()
            ACTION_RESET -> if (created) {
                prefs.edit().remove("x").remove("y").remove("w").remove("h")
                    .remove("tx").remove("ty").apply()
                loadGeometry()
                wm.updateViewLayout(cover, coverLp)
                wm.updateViewLayout(toggle, toggleLp)
            }
            else -> {
                startForegroundCompat()
                if (!created) createViews()
                running = true
            }
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Оверлей", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Миникарта закрыта")
            .setContentText("Нажмите «Выключить», чтобы убрать оверлей")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete),
                    "Выключить", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun loadGeometry() {
        val dm = resources.displayMetrics
        val base = minOf(dm.widthPixels, dm.heightPixels)
        coverLp.x = prefs.getInt("x", dp(8))
        coverLp.y = prefs.getInt("y", dp(8))
        coverLp.width = prefs.getInt("w", base * 3 / 10)
        coverLp.height = prefs.getInt("h", base * 3 / 10)
        toggleLp.x = prefs.getInt("tx", dm.widthPixels / 2)
        toggleLp.y = prefs.getInt("ty", dp(8))
    }

    private fun save() {
        prefs.edit()
            .putInt("x", coverLp.x).putInt("y", coverLp.y)
            .putInt("w", coverLp.width).putInt("h", coverLp.height)
            .putInt("tx", toggleLp.x).putInt("ty", toggleLp.y)
            .apply()
    }

    private fun createViews() {
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val baseFlags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN

        coverLp = WindowManager.LayoutParams(
            100, 100, type, baseFlags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        toggleLp = WindowManager.LayoutParams(
            dp(52), dp(52), type, baseFlags, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        loadGeometry()

        // Закрывающая панель
        cover = FrameLayout(this)
        handleView = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(220, 255, 255, 255))
            }
        }
        cover.addView(
            handleView,
            FrameLayout.LayoutParams(dp(36), dp(36), Gravity.BOTTOM or Gravity.END)
        )

        // Перемещение панели
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        cover.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    dx = e.rawX; dy = e.rawY; sx = coverLp.x; sy = coverLp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    coverLp.x = sx + (e.rawX - dx).toInt()
                    coverLp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(cover, coverLp)
                }
                MotionEvent.ACTION_UP -> save()
            }
            true
        }

        // Изменение размера (кружок в правом нижнем углу)
        var hx = 0f; var hy = 0f; var sw = 0; var sh = 0
        handleView.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    hx = e.rawX; hy = e.rawY; sw = coverLp.width; sh = coverLp.height
                }
                MotionEvent.ACTION_MOVE -> {
                    coverLp.width = max(dp(60), sw + (e.rawX - hx).toInt())
                    coverLp.height = max(dp(60), sh + (e.rawY - hy).toInt())
                    wm.updateViewLayout(cover, coverLp)
                }
                MotionEvent.ACTION_UP -> save()
            }
            true
        }

        // Кнопка переключения режима
        toggle = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 20f
            setTextColor(Color.WHITE)
            alpha = 0.7f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(170, 0, 0, 0))
            }
        }
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var tdx = 0f; var tdy = 0f; var tsx = 0; var tsy = 0; var moved = false
        toggle.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    tdx = e.rawX; tdy = e.rawY; tsx = toggleLp.x; tsy = toggleLp.y
                    moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(e.rawX - tdx) > slop || abs(e.rawY - tdy) > slop) moved = true
                    if (moved) {
                        toggleLp.x = tsx + (e.rawX - tdx).toInt()
                        toggleLp.y = tsy + (e.rawY - tdy).toInt()
                        wm.updateViewLayout(toggle, toggleLp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) save() else {
                        editMode = !editMode
                        applyStyle()
                    }
                }
            }
            true
        }

        wm.addView(cover, coverLp)
        wm.addView(toggle, toggleLp)
        created = true
        applyStyle()
    }

    private fun applyStyle() {
        val opacity = prefs.getInt("opacity", 100)
        val circle = prefs.getBoolean("circle", false)
        val alpha = opacity * 255 / 100

        cover.background = GradientDrawable().apply {
            shape = if (circle) GradientDrawable.OVAL else GradientDrawable.RECTANGLE
            if (!circle) cornerRadius = dp(8).toFloat()
            setColor(Color.argb(alpha, 20, 20, 20))
            if (editMode) setStroke(dp(2), Color.WHITE)
        }
        handleView.visibility = if (editMode) View.VISIBLE else View.GONE
        toggle.text = if (editMode) "🔒" else "✎"

        coverLp.flags = if (editMode) {
            coverLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            coverLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        wm.updateViewLayout(cover, coverLp)
    }

    override fun onDestroy() {
        if (created) {
            try { wm.removeView(cover) } catch (_: Exception) {}
            try { wm.removeView(toggle) } catch (_: Exception) {}
            created = false
        }
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
