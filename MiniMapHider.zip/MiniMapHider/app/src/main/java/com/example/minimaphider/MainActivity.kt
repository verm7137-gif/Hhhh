package com.example.minimaphider

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private val prefs get() = getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun send(action: String) {
        val i = Intent(this, OverlayService::class.java).setAction(action)
        if (action == OverlayService.ACTION_START) startForegroundService(i)
        else if (OverlayService.running) startService(i)
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 16f
        setPadding(0, dp(16), 0, dp(4))
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(24))
        }

        root.addView(TextView(this).apply {
            text = "Скрыть миникарту\n\n" +
                "1. Дайте разрешение «Поверх других окон».\n" +
                "2. Нажмите «Включить» и запустите игру.\n" +
                "3. В игре перетащите панель на миникарту, " +
                "потяните белый кружок, чтобы изменить размер.\n" +
                "4. Нажмите кнопку 🔒 — панель закрепится, касания пойдут в игру.\n" +
                "5. Кнопка ✎ снова включает настройку."
            textSize = 15f
        })

        root.addView(button("1. Разрешить поверх других окон") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        })

        root.addView(button("2. Включить") {
            if (Settings.canDrawOverlays(this)) send(OverlayService.ACTION_START)
            else startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        })

        root.addView(button("Выключить") { send(OverlayService.ACTION_STOP) })

        root.addView(label("Форма панели"))
        val group = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rbSquare = RadioButton(this).apply { text = "Квадрат"; id = 101 }
        val rbCircle = RadioButton(this).apply { text = "Круг"; id = 102 }
        group.addView(rbSquare)
        group.addView(rbCircle)
        group.check(if (prefs.getBoolean("circle", false)) 102 else 101)
        group.setOnCheckedChangeListener { _, id ->
            prefs.edit().putBoolean("circle", id == 102).apply()
            send(OverlayService.ACTION_REFRESH)
        }
        root.addView(group)

        root.addView(label("Непрозрачность панели"))
        root.addView(SeekBar(this).apply {
            max = 70
            progress = prefs.getInt("opacity", 100) - 30
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) {
                        prefs.edit().putInt("opacity", p + 30).apply()
                        send(OverlayService.ACTION_REFRESH)
                    }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })

        root.addView(button("Сбросить положение и размер") {
            if (OverlayService.running) send(OverlayService.ACTION_RESET)
            else prefs.edit().remove("x").remove("y").remove("w").remove("h")
                .remove("tx").remove("ty").apply()
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }
}
